import * as THREE from 'three';
import { CSS3DRenderer, CSS3DObject } from 'three/addons/renderers/CSS3DRenderer.js';
import { gsap } from 'gsap';

/** An inward-facing cylinder of live HTML. Distances are CSS pixels. */
export class FilmRing {
  constructor({ container, elements, radius = 450, height = 380, duration = 45, tilt = 0.15, doubleSided = true } = {}) {
    this.container = typeof container === 'string' ? document.querySelector(container) : container;
    if (!(this.container instanceof HTMLElement)) throw new TypeError('FilmRing requires an HTML container.');
    const content = Array.from(elements ?? this.container.children);
    if (content.length < 3 || content.some((element) => !(element instanceof HTMLElement))) {
      throw new TypeError('FilmRing requires at least three HTML frames.');
    }
    if (![radius, height, duration].every((value) => Number.isFinite(value) && value > 0) || !Number.isFinite(tilt)) {
      throw new RangeError('Radius, height and duration must be positive finite numbers; tilt must be finite.');
    }
    this.radius = radius;
    this.height = height;
    this.doubleSided = doubleSided;
    this.worldNormal = new THREE.Vector3();
    this.worldPosition = new THREE.Vector3();
    this.toCamera = new THREE.Vector3();
    this.frameWidth = 2 * radius * Math.tan(Math.PI / content.length) * 0.98;
    this.destroyed = false;
    this.pauseReasons = new Set();
    this.events = new AbortController();
    this.motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (this.motionPreference.matches) this.pauseReasons.add('reduced-motion');
    if (document.hidden) this.pauseReasons.add('hidden');

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(50, 1, 1, 20000);
    this.group = new THREE.Group();
    this.group.name = 'film-ring';
    this.group.rotation.x = tilt;
    this.scene.add(this.group);
    this.renderer = new CSS3DRenderer();
    this.renderer.domElement.classList.add('film-ring-renderer');
    this.frames = content.map((element, index) => {
      const angle = index / content.length * Math.PI * 2;
      const segment = document.createElement('div');
      segment.className = 'film-ring-frame';
      segment.style.width = `${this.frameWidth}px`;
      segment.style.height = `${height}px`;
      segment.dataset.frame = String(index + 1).padStart(2, '0');
      const face = document.createElement('div');
      face.className = 'film-ring-content';
      face.append(element);
      segment.append(face);
      const frame = new CSS3DObject(segment);
      // +Z is the HTML front. Negative polar coordinates make rotation.y=angle face inward.
      frame.position.set(-radius * Math.sin(angle), 0, -radius * Math.cos(angle));
      frame.rotation.y = angle;
      this.group.add(frame);
      return frame;
    });
    this.container.append(this.renderer.domElement);
    this.timeline = gsap.timeline({ repeat: -1, paused: this.pauseReasons.size > 0 });
    this.timeline.fromTo(this.group.rotation, { y: 0 }, { y: -Math.PI * 2, duration, ease: 'none' });

    const interactionArea = this.container.closest('.filmstrip-viewport') || this.container;
    const listen = (target, name, callback) => target.addEventListener(name, callback, { signal: this.events.signal });
    listen(interactionArea, 'mouseenter', () => this.pause('hover'));
    listen(interactionArea, 'mouseleave', () => this.play('hover'));
    listen(interactionArea, 'focusin', () => this.pause('focus'));
    listen(interactionArea, 'focusout', (event) => {
      if (!interactionArea.contains(event.relatedTarget)) this.play('focus');
    });
    listen(this.motionPreference, 'change', (event) => {
      if (event.matches) this.pause('reduced-motion', true);
      else this.play('reduced-motion');
    });
    listen(document, 'visibilitychange', () => {
      if (document.hidden) this.pause('hidden', true);
      else this.play('hidden');
    });
    listen(window, 'resize', () => this.resize());
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.container);
    this.resize();
    this.tick = this.tick.bind(this);
    this.frameId = requestAnimationFrame(this.tick);
  }

  resize() {
    if (this.destroyed) return;
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height;
    const verticalTangent = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const halfWidth = Math.hypot(this.radius, this.frameWidth / 2);
    const halfHeight = this.height / 2 + this.radius * Math.abs(Math.sin(this.group.rotation.x));
    const fit = Math.max(halfWidth / (verticalTangent * this.camera.aspect), halfHeight / verticalTangent);
    this.camera.position.set(0, this.radius * 0.15, this.radius + fit * 1.12);
    this.camera.far = Math.max(20000, this.camera.position.length() + this.radius * 4);
    this.camera.lookAt(0, 0, 0);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.renderer.render(this.scene, this.camera);
  }

  tick() {
    if (this.destroyed) return;
    this.frameId = requestAnimationFrame(this.tick);
    if (!document.hidden) {
      if (this.doubleSided) {
        this.group.updateMatrixWorld(true);
        this.frames.forEach((frame) => {
          frame.getWorldPosition(this.worldPosition);
          this.worldNormal.set(0, 0, 1).transformDirection(frame.matrixWorld);
          this.toCamera.subVectors(this.camera.position, this.worldPosition);
          // Keep the live HTML readable on either side of the film, without cloning its controls.
          const rotation = this.worldNormal.dot(this.toCamera) < 0 ? 'rotateY(180deg)' : 'rotateY(0deg)';
          const face = frame.element.firstElementChild;
          if (face.style.transform !== rotation) face.style.transform = rotation;
        });
      }
      this.renderer.render(this.scene, this.camera);
    }
  }

  pause(reason = 'manual', immediately = false) {
    if (this.destroyed) return;
    this.pauseReasons.add(reason);
    gsap.killTweensOf(this.timeline);
    if (immediately || this.motionPreference.matches) {
      this.timeline.timeScale(0).pause();
      return;
    }
    gsap.to(this.timeline, {
      timeScale: 0, duration: 0.35, ease: 'power2.out',
      onComplete: () => { if (this.pauseReasons.size) this.timeline.pause(); },
    });
  }

  play(reason = 'manual') {
    if (this.destroyed) return;
    this.pauseReasons.delete(reason);
    if (this.pauseReasons.size) return;
    gsap.killTweensOf(this.timeline);
    this.timeline.play();
    gsap.to(this.timeline, { timeScale: 1, duration: 0.45, ease: 'sine.inOut' });
  }

  toggle() {
    if (this.pauseReasons.has('manual')) this.play('manual');
    else this.pause('manual');
    return this.pauseReasons.has('manual');
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    cancelAnimationFrame(this.frameId);
    this.events.abort();
    this.resizeObserver.disconnect();
    gsap.killTweensOf(this.timeline);
    this.timeline.kill();
    this.group.clear();
    this.scene.clear();
    this.renderer.domElement.remove();
    this.frames.length = 0;
  }
}
