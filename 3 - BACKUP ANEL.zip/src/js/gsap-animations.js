﻿import { gsap } from 'gsap';
import { FilmRing } from './film-ring.js';

let filmstrip = null;

export function initFilmstripAnimation(trackSelector = '#filmstrip-track') {
  const track = document.querySelector(trackSelector);
  if (!track) return null;
  const elements = [...track.querySelectorAll('.film-project-card')];
  filmstrip?.destroy();
  filmstrip = new FilmRing({
    container: track,
    elements,
    radius: 450,
    duration: 45,
    tilt: 0.15,
  });
  return filmstrip;
}

export function pauseFilmstrip(reason = 'viewer') { filmstrip?.pause(reason); }
export function playFilmstrip(reason = 'viewer') { filmstrip?.play(reason); }
export function toggleFilmstrip() { return filmstrip?.toggle() ?? false; }
export function isFilmstripPaused() { return (filmstrip?.pauseReasons.size ?? 0) > 0; }
export function getFilmstripInstance() { return filmstrip; }
export function destroyFilmstrip() {
  filmstrip?.destroy();
  filmstrip = null;
}

export function animatePhoneEntrance(selector = '.phone-screen-container') {
  const container = document.querySelector(selector);
  if (!container) return;
  gsap.fromTo(container, { scale: 0.85, y: 40, opacity: 0 }, {
    scale: 1, y: 0, opacity: 1,
    duration: matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 0.7,
    ease: 'back.out(1.5)', overwrite: true,
  });
}

export function animatePhoneExit(selector = '.phone-screen-container', onComplete) {
  const container = document.querySelector(selector);
  if (!container) { onComplete?.(); return; }
  gsap.to(container, {
    scale: 0.85, y: 30, opacity: 0,
    duration: matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 0.35,
    ease: 'power2.in', overwrite: true, onComplete,
  });
}
