﻿import { gsap } from 'gsap';
import { projectsData } from '../data/projects.js';
import {
  scene, camera, renderer, cloudParticles, starSystem, phoneModel, updateScene, disposeScene,
} from './three-scene.js';
import {
  initFilmstripAnimation, toggleFilmstrip, pauseFilmstrip, playFilmstrip,
  animatePhoneEntrance, animatePhoneExit, destroyFilmstrip,
} from './gsap-animations.js';

let warpSpeed = 0;
let isDark = document.documentElement.dataset.theme === 'dark';
let activeProject = null;
let currentPhotoIndex = 0;
let frameId = 0;
let warpTween = null;
let previousFocus = null;
let savedOverflow = '';
const events = new AbortController();
const motionPreference = matchMedia('(prefers-reduced-motion: reduce)');
const track = document.querySelector('#filmstrip-track');
const pauseButton = document.querySelector('#film-pause-btn');
const themeButton = document.querySelector('#theme-toggle-btn');
const viewer = document.querySelector('#phone-viewer');
const slider = viewer?.querySelector('.phone-slider');
const closeButton = viewer?.querySelector('.close-btn');
const main = document.querySelector('main');
const header = document.querySelector('.top-bar');

function listen(target, name, callback) {
  target?.addEventListener(name, callback, { signal: events.signal });
}

function renderFilmstrip() {
  if (!track) return;
  const fragment = document.createDocumentFragment();
  projectsData.forEach((project) => {
    const card = document.createElement('article');
    card.className = 'film-project-card';
    card.dataset.id = project.id;
    card.tabIndex = 0;
    card.setAttribute('role', 'button');
    card.setAttribute('aria-haspopup', 'dialog');
    card.setAttribute('aria-label', `Abrir ${project.title}, ${project.photos.length} imagens`);
    const media = document.createElement('div');
    media.className = 'card-thumb-container';
    const image = document.createElement('img');
    image.className = 'card-thumb';
    image.src = project.thumb;
    image.alt = project.title;
    image.decoding = 'async';
    image.width = 640;
    image.height = 640;
    media.append(image);
    const info = document.createElement('div');
    info.className = 'card-info';
    const tag = document.createElement('span');
    tag.className = 'card-cat';
    tag.textContent = project.tag;
    const title = document.createElement('h2');
    title.className = 'card-name';
    title.textContent = project.title;
    const hint = document.createElement('span');
    hint.className = 'card-hint';
    hint.textContent = `${project.photos.length} imagens · Abrir projeto ↗`;
    info.append(tag, title, hint);
    card.append(media, info);
    listen(card, 'click', () => openProject(project));
    listen(card, 'keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        openProject(project);
      }
    });
    fragment.append(card);
  });
  track.replaceChildren(fragment);
  initFilmstripAnimation();
}

function updatePauseButton(paused) {
  pauseButton?.classList.toggle('paused', paused);
  pauseButton?.setAttribute('aria-pressed', String(paused));
  pauseButton?.setAttribute('aria-label', paused ? 'Continuar rotação da fita' : 'Pausar rotação da fita');
  const icon = pauseButton?.querySelector('.film-btn-icon');
  const text = pauseButton?.querySelector('.film-btn-text');
  if (icon) icon.textContent = paused ? '▶' : 'Ⅱ';
  if (text) text.textContent = paused ? 'Continuar' : 'Pausar';
}

function openProject(project) {
  if (!viewer || !slider || activeProject) return;
  activeProject = project;
  currentPhotoIndex = 0;
  pauseFilmstrip('viewer');
  previousFocus = document.activeElement;
  savedOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';
  document.querySelector('#phone-tag').textContent = project.tag;
  document.querySelector('#phone-title').textContent = project.title;
  const images = document.createDocumentFragment();
  project.photos.forEach((src, index) => {
    const image = document.createElement('img');
    image.src = src;
    image.alt = `${project.title} — imagem ${index + 1} de ${project.photos.length}`;
    image.decoding = 'async';
    image.loading = index === 0 ? 'eager' : 'lazy';
    image.classList.toggle('active', index === 0);
    images.append(image);
  });
  slider.replaceChildren(images);
  updateCounter();
  viewer.inert = false;
  viewer.classList.add('active');
  viewer.setAttribute('aria-hidden', 'false');
  main.inert = true;
  header.inert = true;
  closeButton?.focus({ preventScroll: true });
  animatePhoneEntrance();
  if (phoneModel) {
    gsap.killTweensOf(phoneModel.scale);
    gsap.killTweensOf(phoneModel.rotation);
    phoneModel.rotation.set(0, Math.PI, 0);
    const duration = motionPreference.matches ? 0 : 0.9;
    gsap.to(phoneModel.scale, { x: 5, y: 5, z: 5, duration, ease: 'back.out(1.7)' });
    gsap.to(phoneModel.rotation, { y: Math.PI * 3, duration, ease: 'back.out(1.7)' });
  }
}

function updateCounter() {
  if (activeProject) document.querySelector('#phone-counter').textContent = `${currentPhotoIndex + 1} / ${activeProject.photos.length}`;
}

export function changePhoto(direction) {
  if (!activeProject || !slider || !['next', 'prev'].includes(direction)) return;
  const images = slider.querySelectorAll('img');
  images[currentPhotoIndex]?.classList.remove('active');
  currentPhotoIndex = (currentPhotoIndex + (direction === 'next' ? 1 : -1) + images.length) % images.length;
  images[currentPhotoIndex]?.classList.add('active');
  updateCounter();
  if (motionPreference.matches) return;
  if (direction === 'next' && !isDark) {
    cloudParticles.forEach((cloud, index) => {
      gsap.to(cloud.position, {
        z: cloud.position.z + 12, x: cloud.position.x + (index % 2 ? -1 : 1),
        duration: 0.7, ease: 'sine.inOut', overwrite: true,
        onUpdate: () => {
          if (cloud.position.z > 40) {
            gsap.killTweensOf(cloud.position);
            cloud.position.z = -40;
          }
        },
      });
    });
  } else if (direction === 'next' && isDark) {
    warpTween?.kill();
    const wave = { progress: 0 };
    warpTween = gsap.to(wave, {
      progress: 1, duration: 0.7, ease: 'none',
      onUpdate: () => { warpSpeed = Math.sin(Math.PI * wave.progress) * 2; },
      onComplete: () => { warpSpeed = 0; },
    });
  }
  if (phoneModel) {
    gsap.killTweensOf(phoneModel.rotation, 'z');
    gsap.fromTo(phoneModel.rotation, { z: direction === 'next' ? -0.06 : 0.06 }, {
      z: 0, duration: 0.6, ease: 'elastic.out(1, 0.3)',
    });
  }
}

export function closePhone() {
  if (!viewer || !activeProject) return;
  activeProject = null;
  viewer.setAttribute('aria-hidden', 'true');
  viewer.inert = true;
  viewer.classList.remove('active');
  document.body.style.overflow = savedOverflow;
  main.inert = false;
  header.inert = false;
  previousFocus?.focus({ preventScroll: true });
  animatePhoneExit();
  warpTween?.kill();
  warpSpeed = 0;
  if (phoneModel) {
    gsap.killTweensOf(phoneModel.scale);
    gsap.killTweensOf(phoneModel.rotation);
    gsap.to(phoneModel.scale, {
      x: 0, y: 0, z: 0, duration: motionPreference.matches ? 0 : 0.4, ease: 'power2.in',
    });
  }
  playFilmstrip('viewer');
}

export function switchTheme(mode) {
  if (!['dark', 'light'].includes(mode)) return;
  isDark = mode === 'dark';
  document.body.dataset.theme = mode;
  document.documentElement.dataset.theme = mode;
  themeButton?.setAttribute('aria-pressed', String(isDark));
  themeButton?.setAttribute('aria-label', isDark ? 'Ativar tema claro' : 'Ativar tema escuro');
  const duration = motionPreference.matches ? 0 : 0.8;
  cloudParticles.forEach((cloud) => {
    gsap.killTweensOf(cloud.material);
    if (!isDark) cloud.visible = true;
    gsap.to(cloud.material, {
      opacity: isDark ? 0 : 0.8, duration, ease: 'power2.inOut',
      onComplete: () => { cloud.visible = !isDark; },
    });
  });
  gsap.killTweensOf(starSystem.material);
  if (isDark && !starSystem.visible) {
    starSystem.material.opacity = 0;
    starSystem.visible = true;
  }
  gsap.to(starSystem.material, {
    opacity: isDark ? 0.8 : 0, duration, ease: 'power2.inOut',
    onComplete: () => { starSystem.visible = isDark; },
  });
  if (!isDark) { warpTween?.kill(); warpSpeed = 0; }
}

if (viewer) {
  viewer.inert = true;
  viewer.setAttribute('role', 'dialog');
  viewer.setAttribute('aria-modal', 'true');
  viewer.setAttribute('aria-label', 'Imagens do projeto');
}
listen(pauseButton, 'click', () => updatePauseButton(toggleFilmstrip()));
listen(themeButton, 'click', () => switchTheme(isDark ? 'light' : 'dark'));
listen(viewer?.querySelector('.next-photo'), 'click', () => changePhoto('next'));
listen(viewer?.querySelector('.prev-photo'), 'click', () => changePhoto('prev'));
listen(closeButton, 'click', closePhone);
listen(viewer, 'click', (event) => { if (event.target === viewer) closePhone(); });
listen(window, 'keydown', (event) => {
  if (!activeProject) return;
  if (event.key === 'Escape') closePhone();
  if (['ArrowLeft', 'ArrowRight'].includes(event.key)) {
    event.preventDefault();
    changePhoto(event.key === 'ArrowRight' ? 'next' : 'prev');
  }
  if (event.key === 'Tab') {
    const controls = [...viewer.querySelectorAll('button')];
    const first = controls[0];
    const last = controls.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});
renderFilmstrip();
switchTheme(isDark ? 'dark' : 'light');

function tick() {
  frameId = requestAnimationFrame(tick);
  if (document.hidden) return;
  if (!motionPreference.matches) updateScene(warpSpeed, isDark);
  renderer?.render(scene, camera);
}
tick();

if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    closePhone();
    events.abort();
    cancelAnimationFrame(frameId);
    warpTween?.kill();
    destroyFilmstrip();
    cloudParticles.forEach((cloud) => {
      gsap.killTweensOf(cloud.material);
      gsap.killTweensOf(cloud.position);
    });
    gsap.killTweensOf(starSystem.material);
    gsap.killTweensOf(phoneModel.scale);
    gsap.killTweensOf(phoneModel.rotation);
    gsap.killTweensOf('.phone-screen-container');
    disposeScene();
  });
}
