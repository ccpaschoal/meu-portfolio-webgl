﻿import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const canvas = document.querySelector('#bg-canvas');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 1, 1000);
camera.position.z = 50;

let renderer = null;
if (canvas) {
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
  } catch (error) {
    canvas.hidden = true;
    console.warn('WebGL indisponível; a galeria continua disponível.', error);
  }
}
scene.add(new THREE.AmbientLight(0xffffff, 0.7));
const directionalLight = new THREE.DirectionalLight(0x0077b5, 0.8);
directionalLight.position.set(0, 0, 1);
scene.add(directionalLight);

function createCloudTexture() {
  const textureCanvas = document.createElement('canvas');
  textureCanvas.width = 128;
  textureCanvas.height = 128;
  const context = textureCanvas.getContext('2d');
  if (!context) throw new Error('Não foi possível criar a textura das nuvens.');
  const gradient = context.createRadialGradient(64, 64, 0, 64, 64, 64);
  gradient.addColorStop(0, 'rgba(255,255,255,0.6)');
  gradient.addColorStop(0.4, 'rgba(255,255,255,0.3)');
  gradient.addColorStop(1, 'rgba(255,255,255,0)');
  context.fillStyle = gradient;
  context.fillRect(0, 0, 128, 128);
  const texture = new THREE.CanvasTexture(textureCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

const cloudTexture = createCloudTexture();
const cloudGeometry = new THREE.PlaneGeometry(40, 40);
const cloudParticles = [];
for (let index = 0; index < 25; index += 1) {
  const material = new THREE.MeshLambertMaterial({
    map: cloudTexture, transparent: true, opacity: 0.8, depthWrite: false,
  });
  const cloud = new THREE.Mesh(cloudGeometry, material);
  cloud.position.set((Math.random() - 0.5) * 100, (Math.random() - 0.5) * 70, Math.random() * 75 - 40);
  cloud.rotation.z = Math.random() * Math.PI * 2;
  cloudParticles.push(cloud);
  scene.add(cloud);
}

const STAR_COUNT = 1500;
const starGeometry = new THREE.BufferGeometry();
const starPositions = new Float32Array(STAR_COUNT * 3);
const starSpeeds = new Float32Array(STAR_COUNT);
for (let index = 0; index < STAR_COUNT; index += 1) {
  const angle = Math.random() * Math.PI * 2;
  const radius = 3 + Math.sqrt(Math.random()) * 70;
  starPositions[index * 3] = Math.cos(angle) * radius;
  starPositions[index * 3 + 1] = Math.sin(angle) * radius;
  starPositions[index * 3 + 2] = Math.random() * 100 - 50;
  starSpeeds[index] = 0.2 + Math.random() * 0.8;
}
starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
starGeometry.attributes.position.setUsage(THREE.DynamicDrawUsage);
const starMaterial = new THREE.PointsMaterial({
  color: 0xffffff, size: 0.25, transparent: true, opacity: 0.8,
  sizeAttenuation: true, depthWrite: false,
});
const starSystem = new THREE.Points(starGeometry, starMaterial);
starSystem.visible = false;
// Dynamic positions remain inside this bound when their Z coordinates wrap.
starGeometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 100);
scene.add(starSystem);

const gltfLoader = new GLTFLoader();
let phoneModel = null;
// Stable mock transform; no network request until a real GLTF URL is supplied.
phoneModel = new THREE.Group();
phoneModel.name = 'phone-model';
phoneModel.scale.set(0, 0, 0);
phoneModel.rotation.y = Math.PI;
scene.add(phoneModel);

export async function loadPhoneModel(url) {
  const gltf = await gltfLoader.loadAsync(url);
  const previousChildren = [...phoneModel.children];
  phoneModel.clear();
  previousChildren.forEach(disposeObject);
  phoneModel.add(gltf.scene);
  return phoneModel;
}

function disposeObject(object) {
  object.traverse((child) => {
    child.geometry?.dispose();
    const materials = Array.isArray(child.material) ? child.material : [child.material];
    materials.filter(Boolean).forEach((material) => {
      Object.values(material).forEach((value) => {
        if (value?.isTexture) value.dispose();
      });
      material.dispose();
    });
  });
}

function resizeScene() {
  const width = Math.max(window.innerWidth, 1);
  const height = Math.max(window.innerHeight, 1);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer?.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer?.setSize(width, height);
}
window.addEventListener('resize', resizeScene, { passive: true });

let previousFrame = 0;
function updateScene(warpSpeed = 0, isDark = false) {
  const now = performance.now();
  const frameScale = previousFrame ? Math.min((now - previousFrame) / (1000 / 60), 3) : 1;
  previousFrame = now;
  const speed = Number.isFinite(warpSpeed) ? Math.max(0, warpSpeed) : 0;
  // Visibility belongs to the theme tweens so both particle systems can crossfade.
  cloudParticles.forEach((cloud) => {
    if (cloud.visible) cloud.rotation.z += 0.0005 * frameScale;
  });
  if (!starSystem.visible && !isDark) return;
  if (starSystem.visible) {
    const positions = starGeometry.attributes.position;
    for (let index = 0; index < STAR_COUNT; index += 1) {
      const z = index * 3 + 2;
      positions.array[z] += ((starSpeeds[index] * 0.1) + (speed * starSpeeds[index] * 5)) * frameScale;
      if (positions.array[z] > 50) positions.array[z] = -50;
    }
    positions.needsUpdate = true;
  }
}

export function disposeScene() {
  window.removeEventListener('resize', resizeScene);
  cloudGeometry.dispose();
  cloudTexture.dispose();
  cloudParticles.forEach((cloud) => cloud.material.dispose());
  starGeometry.dispose();
  starMaterial.dispose();
  disposeObject(phoneModel);
  scene.clear();
  renderer?.dispose();
}

export { scene, camera, renderer, cloudParticles, starSystem, starGeometry, starSpeeds, phoneModel, updateScene };
