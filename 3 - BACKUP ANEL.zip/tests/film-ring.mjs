import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';
import { createServer } from 'vite';
const server = await createServer({ server: { host: '127.0.0.1', port: 0, open: false, strictPort: false } });
await server.listen();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
try {
  await page.goto(`http://127.0.0.1:${server.httpServer.address().port}`, { waitUntil: 'networkidle' });
  assert.equal(await page.locator('.film-ring-renderer').count(), 1, 'The filmstrip must use a CSS3DRenderer surface');
  const geometry = await page.evaluate(async () => {
    const url = performance.getEntriesByType('resource').find((entry) => entry.name.includes('/js/gsap-animations.js')).name;
    const { getFilmstripInstance } = await import(url);
    const ring = getFilmstripInstance();
    window.filmRingUnderTest = ring;
    return {
      count: ring.frames.length,
      radius: ring.radius,
      tilt: ring.group.rotation.x,
      distances: ring.frames.map((frame) => Math.hypot(frame.position.x, frame.position.z)),
      normals: ring.frames.map((frame) => {
        const normal = frame.position.clone().set(Math.sin(frame.rotation.y), 0, Math.cos(frame.rotation.y));
        const inward = frame.position.clone().negate().normalize();
        return normal.dot(inward);
      }),
      repeat: ring.timeline.repeat(),
    };
  });
  assert.ok(geometry.count >= 8);
  assert.equal(geometry.radius, 450);
  assert.equal(geometry.tilt, 0.15);
  assert.equal(geometry.repeat, -1);
  assert.ok(geometry.distances.every((value) => Math.abs(value - 450) < 0.0001));
  assert.ok(geometry.normals.every((value) => value > 0.9999), 'Every frame must face inward');
  const angle = () => page.evaluate(() => window.filmRingUnderTest.group.rotation.y);
  await page.mouse.move(5, 5);
  const start = await angle();
  await page.waitForTimeout(700);
  assert.ok((await angle()) < start, 'The ring must spin clockwise continuously');
  await page.locator('#filmstrip-viewport').hover({ position: { x: 8, y: 8 } });
  await page.waitForTimeout(600);
  const stopped = await angle();
  await page.waitForTimeout(250);
  assert.ok(Math.abs((await angle()) - stopped) < 0.001, 'Hover must pause rotation');
  await page.mouse.move(5, 5);
  await page.waitForTimeout(700);
  assert.ok((await angle()) < stopped, 'Mouse leave must resume rotation');
  await page.locator('#film-pause-btn').click();
  await page.waitForTimeout(600);
  const manual = await angle();
  await page.locator('#filmstrip-viewport').hover({ position: { x: 8, y: 8 } });
  await page.mouse.move(5, 5);
  await page.waitForTimeout(700);
  assert.ok(Math.abs((await angle()) - manual) < 0.001, 'Mouse leave must preserve manual pause');
  const images = await page.locator('.film-project-card img').evaluateAll((nodes) => nodes.map((img) => ({
    src: img.getAttribute('src'), loaded: img.complete && img.naturalWidth > 0,
  })));
  assert.ok(images.every((img) => img.src.startsWith('/assets/carrosseis/') && img.loaded), 'Portfolio images must be local and loaded');
  // Click a frame that is actually in front; rear frames can be occluded by the cylinder.
  const visibleId = await page.locator('.film-project-card').evaluateAll((cards) => {
    return cards.find((card) => {
      const bounds = card.getBoundingClientRect();
      return document.elementFromPoint(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2)?.closest('.film-project-card') === card;
    })?.dataset.id;
  });
  assert.ok(visibleId, 'At least one project must be visible and clickable');
  const card = page.locator(`.film-project-card[data-id="${visibleId}"]`);
  await card.click();
  assert.equal(await page.locator('#phone-viewer').getAttribute('aria-hidden'), 'false');
  await page.waitForTimeout(1000);
  await page.screenshot({ path: 'logs/GALERIA-DESKTOP.png' });
  const first = await page.locator('.phone-slider img.active').getAttribute('src');
  await page.locator('.next-photo').click();
  assert.notEqual(await page.locator('.phone-slider img.active').getAttribute('src'), first);
  await page.keyboard.press('Escape');
  assert.equal(await page.locator('#phone-viewer').getAttribute('aria-hidden'), 'true');
  await page.locator('#theme-toggle-btn').click();
  assert.equal(await page.locator('body').getAttribute('data-theme'), 'dark');
  await page.waitForTimeout(1000);
  await page.screenshot({ path: 'logs/ANEL-DESKTOP.png' });
  for (const width of [1024, 768, 390]) {
    await page.setViewportSize({ width, height: 844 });
    await page.waitForTimeout(400);
    assert.equal(await page.locator('.film-ring-renderer').evaluate((element) => Math.round(element.getBoundingClientRect().width)), width);
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await page.screenshot({ path: `logs/ANEL-${width}.png` });
  }
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.waitForTimeout(200);
  const reduced = await angle();
  await page.waitForTimeout(300);
  assert.ok(Math.abs((await angle()) - reduced) < 0.001);
  await page.evaluate(async () => {
    const { FilmRing } = await import('/js/film-ring.js');
    const mount = document.createElement('div');
    mount.style.cssText = 'width:600px;height:400px';
    document.body.append(mount);
    const frames = Array.from({ length: 8 }, () => document.createElement('div'));
    const input = document.createElement('input');
    input.value = 'Conteúdo HTML real';
    frames[0].append(input);
    const ring = new FilmRing({ container: mount, elements: frames, radius: 600 });
    if (ring.frames.some((frame) => Math.abs(frame.position.length() - 600) > 0.001)) throw new Error('Custom radius failed');
    if (mount.querySelector('input') !== input || input.value !== 'Conteúdo HTML real') throw new Error('Live HTML state was lost');
    ring.destroy();
    if (mount.children.length) throw new Error('Renderer cleanup failed');
    mount.remove();
  });
  await page.evaluate(async () => {
    const url = performance.getEntriesByType('resource').find((entry) => entry.name.includes('/js/gsap-animations.js')).name;
    const { initFilmstripAnimation } = await import(url);
    const first = initFilmstripAnimation();
    const second = initFilmstripAnimation();
    if (!first.destroyed || second.frames.length !== 10 || document.querySelectorAll('.film-ring-renderer').length !== 1) throw new Error('Repeated initialization leaked a renderer');
  });
  assert.deepEqual(errors, []);
  console.log('PASS: CSS3D, inward normals, radius, tilt, infinite spin, smooth hover, manual pause, local portfolio images, gallery, theme, responsive sizes, reduced motion, custom radius and cleanup.');
} finally {
  await browser.close();
  await server.close();
}
