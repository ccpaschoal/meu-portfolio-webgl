# Portfólio 3D — Camilla Paschoal

Experimento independente com 10 carrosséis reais do portfólio. As capas e todas as imagens da galeria são locais. O site original não foi alterado.

## Abrir

Dê dois cliques em **1 - ABRIR PORTFÓLIO 3D.bat**. Ou, nesta pasta, execute `npm.cmd run dev` e acesse http://localhost:3000.

`npm.cmd install` instala as dependências em uma cópia nova do projeto. `npm.cmd run build` gera a versão de produção. `npm.cmd test` inicia um servidor temporário, executa os testes no Edge sem abrir uma janela e encerra esse servidor.

## Arquivos

- `src/js/film-ring.js`: componente reutilizável `FilmRing`, com cena CSS3D, câmera, animação, pausas, resize e destruição.
- `src/js/gsap-animations.js`: integração do anel e animações do visualizador.
- `src/js/main.js`: projetos, temas e galeria.
- `src/js/three-scene.js`: fundo WebGL de nuvens/estrelas e grupo vazio para um futuro modelo GLTF.
- `src/data/projects.js`: títulos, capas e sequências reais dos projetos.
- `public/assets/`: cópias das imagens, fonte e logo do portfólio.
- `scripts/sync-portfolio.py`: importa novamente os carrosséis referenciados no HTML do site original.
- `tests/film-ring.mjs`: testes de geometria, orientação, interação, imagens e responsividade.
- `logs/`: resultados e capturas de tela. `RENOMEACAO-LOG.csv` registra a organização dos arquivos.

## Usar o componente em outro layout

Importe `FilmRing` de `src/js/film-ring.js` e instancie com `new FilmRing({ container, elements, radius: 450, height: 380, duration: 45, tilt: 0.15 })`. `container` aceita um elemento HTML ou seletor; `elements` aceita uma coleção de pelo menos três elementos HTML. Dê ao container largura e altura por CSS e reutilize as regras `.film-ring-*`.

Os elementos originais são movidos para a cena, preservando campos, eventos e carrosséis. As posições ficam em um círculo no plano XZ; cada objeto aponta para o centro. `doubleSided: true` mantém o conteúdo legível nos dois lados sem clonar controles; passe `false` para manter apenas a orientação original do HTML.

`pause()` e `play()` controlam a pausa manual; `toggle()` alterna essa pausa; `destroy()` remove renderer, listeners, observer, timeline e loop. A pausa também respeita mouse, foco de teclado, galeria aberta, aba oculta e preferência por movimento reduzido. Sair com o mouse não desfaz a pausa manual.

Para mudar o raio ou a velocidade desta página, ajuste as opções em `initFilmstripAnimation()`, em `gsap-animations.js`. Para usar um modelo real, chame `loadPhoneModel(url)` de `three-scene.js` com seu arquivo GLTF/GLB.

## Referências técnicas

[CSS3DRenderer — Three.js](https://threejs.org/docs/pages/CSS3DRenderer.html) · [Controle suave de timeScale — GSAP](https://gsap.com/docs/v3/GSAP/Timeline/timeScale()/)

O build separa aplicação, GSAP, addons e núcleo do Three.js. O núcleo ainda gera o aviso de tamanho do Vite: aproximadamente 519 kB minificados (131 kB gzip).
